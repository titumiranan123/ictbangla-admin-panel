/* eslint-disable @typescript-eslint/no-explicit-any */

import SignInComponent from "./SignIn";

export default async function SignInPage() {
  return (
    <>
      <SignInComponent  />
    </>
  );
}
