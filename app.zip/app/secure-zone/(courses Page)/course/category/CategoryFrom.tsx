import React from 'react';

const CategoryFrom = () => {
    return (
        <div className='md:w-[450px] h-[500px] bg-slate-100 rounded-lg'>
            
        </div>
    );
};

export default CategoryFrom;