"use client";

import React from "react";
import UserTable from "./UserTable";

const Allusers = () => {

  return (
    <div className="container sections">
      
        <UserTable  />

    </div>
  );
};

export default Allusers;
